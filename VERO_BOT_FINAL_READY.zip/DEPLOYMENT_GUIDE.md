# 🚀 VERO Bot - Deployment Guide

## Что было исправлено

### ✅ AI Оптимизация (экономия ~70%)
**Было**: 3+ запроса на новость
**Стало**: 1 запрос на новость (unified analysis)

### ✅ Картинки (100% надежность)
- Валидация URL перед отправкой
- 5 проверенных fallback-картинок
- Никогда не падает из-за битых ссылок

### ✅ Формат постов (по ТЗ)
- Термины В СКОБКАХ: "ETF (биржевой фонд)"
- Точная формулировка: "Может привести к"
- Чистый HTML без markdown

### ✅ Безопасность
- Все ключи через .env (нет хардкода)

## 🔧 Быстрый старт

### 1. Распакуй и установи
```bash
unzip VERO_BOT_GITHUB_READY.zip
cd vero_export
npm install
```

### 2. Создай .env
```bash
cp .env.example .env
```

Заполни:
```env
TELEGRAM_BOT_TOKEN=твой_токен_от_botfather
ADMIN_TELEGRAM_ID=твой_telegram_id
DATABASE_URL=postgresql://user:pass@host:5432/db
ABACUSAI_API_KEY=твой_ключ
APP_ORIGIN=https://your-domain.com
```

### 3. База данных
```bash
npx prisma generate
npx prisma migrate deploy
```

### 4. Запуск
```bash
npm run start:dev  # локально
npm run start:prod # продакшн
```

## 🌐 Деплой на Render

1. Push на GitHub
2. Render.com → New Web Service
3. Connect GitHub repo
4. Добавь env variables
5. Deploy!

### Настрой webhook
```bash
curl "https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://your-app.onrender.com/webhook/telegram"
```

## 🎯 Настройка каналов

Добавь бота **администратором** в:
- @vero_crypto_news (EN)
- @vero_crypto_news_ru (RU)

Права: Post messages ✅

## 🧪 Тестирование

```bash
# Ручное сканирование
curl -X POST https://your-app.com/admin/scan-now

# Ручной постинг
curl -X POST https://your-app.com/admin/broadcast-now
```

## 📊 Мониторинг логов

Ищи в Render Logs:
- `🔍 Starting 15-minute news scan` - сканирование
- `✓ Added to buffer: RED` - новость проанализирована
- `📢 Starting hourly broadcast` - постинг
- `✓ Posted to @channel` - успешно

## 🚨 Troubleshooting

### Бот не постит?
1. Проверь права бота (админ + post messages)
2. Проверь webhook: `/getWebhookInfo`
3. Проверь токен: `/getMe`

### AI ошибки?
1. Проверь баланс на Abacus.AI
2. Админ получит уведомление в Telegram

### Картинки?
- Fallback система всегда работает
- Логи покажут: "Using fallback image"

## ✅ Чеклист

- [ ] .env заполнен
- [ ] База мигрирована
- [ ] Код на GitHub
- [ ] Render задеплоен
- [ ] Webhook настроен
- [ ] Бот админ в каналах
- [ ] Тест scan-now ✓
- [ ] Тест broadcast-now ✓

**Готово! Бот работает автоматически.**

## 💰 Стоимость

- Render Free tier: $0
- PostgreSQL: $7/мес (после 90 дней free)
- AI (GPT-4o-mini): ~$5-10/мес

**Экономия 70% благодаря unified analysis!**
